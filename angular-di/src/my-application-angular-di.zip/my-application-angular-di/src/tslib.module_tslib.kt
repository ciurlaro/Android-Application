@file:Suppress("INTERFACE_WITH_SUPERCLASS", "OVERRIDING_FINAL_MEMBER", "RETURN_TYPE_MISMATCH_ON_OVERRIDE", "CONFLICTING_OVERLOADS", "EXTERNAL_DELEGATION")

import kotlin.js.*
import kotlin.js.Json
import org.khronos.webgl.*
import org.w3c.dom.*
import org.w3c.dom.events.*
import org.w3c.dom.parsing.*
import org.w3c.dom.svg.*
import org.w3c.dom.url.*
import org.w3c.fetch.*
import org.w3c.files.*
import org.w3c.notifications.*
import org.w3c.performance.*
import org.w3c.workers.*
import org.w3c.xhr.*

external fun __extends(d: Function<*>, b: Function<*>)

external fun __assign(t: Any, vararg sources: Any): Any

external fun __rest(t: Any, propertyNames: Array<dynamic /* String | Any */>): Any

external fun __decorate(decorators: Array<Function<*>>, target: Any, key: String? = definedExternally, desc: Any? = definedExternally): Any

external fun __decorate(decorators: Array<Function<*>>, target: Any, key: Any? = definedExternally, desc: Any? = definedExternally): Any

external fun __param(paramIndex: Number, decorator: Function<*>): Function<*>

external fun __metadata(metadataKey: Any, metadataValue: Any): Function<*>

external fun __awaiter(thisArg: Any, _arguments: Any, P: Function<*>, generator: Function<*>): Any

external fun __generator(thisArg: Any, body: Function<*>): Any

external fun __exportStar(m: Any, exports: Any)

external fun __values(o: Any): Any

external fun __read(o: Any, n: Number? = definedExternally): Array<Any>

external fun __spread(vararg args: Array<Any>): Array<Any>

external fun __spreadArrays(vararg args: Array<Any>): Array<Any>

external fun __await(v: Any): Any

external fun __asyncGenerator(thisArg: Any, _arguments: Any, generator: Function<*>): Any

external fun __asyncDelegator(o: Any): Any

external fun __asyncValues(o: Any): Any

external fun __makeTemplateObject(cooked: Array<String>, raw: Array<String>): Array<String>

external fun <T> __importStar(mod: T): T

external interface `T$0`<T> {
    var default: T
}

external fun <T> __importDefault(mod: T): dynamic /* T | `T$0`<T> */

external fun __decorate(decorators: Array<Function<*>>, target: Any): Any